# XF2A-Badges
Easily create rules and group them into categories. Bring the power of law to your community!
